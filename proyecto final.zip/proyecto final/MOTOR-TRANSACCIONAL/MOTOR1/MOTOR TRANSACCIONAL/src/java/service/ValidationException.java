package service;

/*Excepcion de validacion*/
public class ValidationException extends Exception{
    public ValidationException(String message) {super(message);}
}
