package service;

public class RepositoryException extends Exception{
    public RepositoryException(String message, Throwable cause) {super(message, cause);}
}