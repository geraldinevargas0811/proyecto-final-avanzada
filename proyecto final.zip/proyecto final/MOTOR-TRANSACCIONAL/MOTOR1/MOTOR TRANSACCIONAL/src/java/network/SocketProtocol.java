package network;

public final class SocketProtocol {
    private SocketProtocol(){}
    
    public static final String MSG_OK = "OK";
    public static final String MSG_ERROR = "ERROR";
}
